# DashMamad Dashboard

Android Studio project for the personal dashboard app.

Included:
- Provided cat/rose portrait background.
- Live large gold clock.
- Music browser with background playback service.
- Book/notes editor with persistent storage.
- Book customization foundation (font size/text color + gallery picker persistence).
- 10 workout slots with view/edit separation and persistent notes.
- Light/Dark mode.
- Portrait orientation.

Open this folder in Android Studio and build an APK.
